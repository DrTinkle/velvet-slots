// ============================================================
//  BootScene.js
//  Loads all assets. Shows a simple loading bar.
//  When complete, starts GameScene.
// ============================================================

export class BootScene extends Phaser.Scene {
  constructor() {
    super({ key: 'BootScene' });
  }

  preload() {
    const { width, height } = this.scale;

    // ── Loading bar ──────────────────────────────────────────
    const barBg = this.add.rectangle(width / 2, height / 2, 400, 12, 0x222222);
    const bar   = this.add.rectangle(
      width / 2 - 200, height / 2, 0, 12, 0xc9a84c
    ).setOrigin(0, 0.5);

    const label = this.add.text(width / 2, height / 2 - 30, 'LOADING...', {
      fontFamily: 'serif',
      fontSize:   '18px',
      color:      '#c9a84c',
      letterSpacing: 6,
    }).setOrigin(0.5);

    this.load.on('progress', (value) => {
      bar.width = 400 * value;
    });

    // ── For now we generate all graphics procedurally ───────
    // When real art assets exist, load them here:
    // this.load.image('sym_low_a', 'assets/symbols/low_a.png');
    // etc.

    // Generate symbol textures programmatically
    this.load.on('complete', () => {
      this._generateTextures();
      label.setText('READY');
    });
  }

  _generateTextures() {
    const { CELL_SIZE } = { CELL_SIZE: 96 };
    const S = CELL_SIZE;

    // Symbol definitions [id, color, label, shape]
    const symbols = [
      { id: 'low_a',          color: 0x6c8ebf, label: 'A',  shape: 'diamond'  },
      { id: 'low_b',          color: 0x82b366, label: 'B',  shape: 'circle'   },
      { id: 'mid_a',          color: 0xd79b00, label: 'C',  shape: 'square'   },
      { id: 'mid_b',          color: 0xae4132, label: 'D',  shape: 'triangle' },
      { id: 'high_a',         color: 0x9673a6, label: 'E',  shape: 'hexagon'  },
      { id: 'high_b',         color: 0xe6c84a, label: 'F',  shape: 'star'     },
      { id: 'extra_a',        color: 0x4fc3f7, label: 'G',  shape: 'circle'   },
      { id: 'extra_b',        color: 0xf06292, label: 'H',  shape: 'square'   },
      { id: 'wild',           color: 0xffffff, label: 'W',  shape: 'star'     },
      { id: 'wild_expanding', color: 0x00e5ff, label: 'EW', shape: 'diamond'  },
      { id: 'wild_sticky',    color: 0x69f0ae, label: 'SW', shape: 'circle'   },
      { id: 'wild_multiplier',color: 0xffab40, label: 'MW', shape: 'hexagon'  },
      { id: 'wild_sticky_mult',color:0xea80fc, label: 'SMW',shape: 'star'     },
      { id: 'scatter',        color: 0xff1744, label: 'SC', shape: 'star'     },
    ];

    for (const sym of symbols) {
      if (this.textures.exists(sym.id)) continue;

      const g = this.make.graphics({ x: 0, y: 0, add: false });

      // Background tile
      g.fillStyle(0x111111, 1);
      g.fillRoundedRect(2, 2, S - 4, S - 4, 10);

      // Coloured shape
      g.fillStyle(sym.color, 1);
      g.lineStyle(2, 0xffffff, 0.15);

      this._drawShape(g, sym.shape, S);

      // Border glow for specials
      if (sym.id.startsWith('wild') || sym.id === 'scatter') {
        g.lineStyle(2, sym.color, 0.8);
        g.strokeRoundedRect(2, 2, S - 4, S - 4, 10);
      }

      g.generateTexture(sym.id, S, S);
      g.destroy();
    }

    // Multiplier badge textures (2x, 3x, 5x, 10x)
    for (const val of [2, 3, 5, 10]) {
      const key = `mult_badge_${val}`;
      if (this.textures.exists(key)) continue;
      const g = this.make.graphics({ x: 0, y: 0, add: false });
      g.fillStyle(0xffab40, 1);
      g.fillRoundedRect(0, 0, 36, 20, 6);
      g.generateTexture(key, 36, 20);
      g.destroy();
    }
  }

  _drawShape(g, shape, S) {
    const cx = S / 2, cy = S / 2, r = S * 0.32;
    switch (shape) {
      case 'circle':
        g.fillCircle(cx, cy, r);
        break;
      case 'square':
        g.fillRect(cx - r, cy - r, r * 2, r * 2);
        break;
      case 'diamond': {
        const pts = [
          { x: cx,     y: cy - r * 1.2 },
          { x: cx + r, y: cy           },
          { x: cx,     y: cy + r * 1.2 },
          { x: cx - r, y: cy           },
        ];
        g.fillPoints(pts, true);
        break;
      }
      case 'triangle': {
        const pts = [
          { x: cx,         y: cy - r * 1.2 },
          { x: cx + r * 1.1, y: cy + r * 0.8 },
          { x: cx - r * 1.1, y: cy + r * 0.8 },
        ];
        g.fillPoints(pts, true);
        break;
      }
      case 'hexagon': {
        const pts = [];
        for (let i = 0; i < 6; i++) {
          const angle = (Math.PI / 3) * i - Math.PI / 6;
          pts.push({ x: cx + r * Math.cos(angle), y: cy + r * Math.sin(angle) });
        }
        g.fillPoints(pts, true);
        break;
      }
      case 'star': {
        const pts = [];
        const outerR = r, innerR = r * 0.45, points = 5;
        for (let i = 0; i < points * 2; i++) {
          const angle  = (Math.PI / points) * i - Math.PI / 2;
          const radius = i % 2 === 0 ? outerR : innerR;
          pts.push({ x: cx + radius * Math.cos(angle), y: cy + radius * Math.sin(angle) });
        }
        g.fillPoints(pts, true);
        break;
      }
    }
  }

  create() {
    this.scene.start('GameScene');
    this.scene.launch('UIScene');
  }
}
