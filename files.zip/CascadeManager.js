// ============================================================
//  CascadeManager.js
//  Orchestrates one full cascade chain (pure logic layer).
//  Returns a step-by-step result that GameScene animates.
// ============================================================

import { Grid }            from './Grid.js';
import { WildHandler }     from './WildHandler.js';
import { detectClusters, countScatters, getWinningCells, checkEdgeTouching }
  from './Cluster.js';
import { calculatePayout } from './PayCalculator.js';

export class CascadeManager {
  constructor() {
    this.grid        = new Grid();
    this.wildHandler = new WildHandler();
    this.isBonus     = false;
    this.chainMult   = 1;   // bonus game accumulating multiplier
  }

  // ── Start a fresh spin ────────────────────────────────────
  // keepSticky: true during bonus (sticky wilds persist)
  // Returns a CascadeResult object (see below).
  startSpin(bet, keepSticky = false) {
    this.grid.reset(keepSticky);
    if (!keepSticky) {
      // base game: reset chain multiplier
      this.chainMult = 1;
    }
    return this._runCascadeChain(bet);
  }

  // ── Run the full cascade chain from current grid state ────
  _runCascadeChain(bet) {
    const steps     = [];
    let   totalWin  = 0;
    let   scatters  = 0;

    // ── Step 0: Expanding wilds (before first cluster check) ─
    const expansions = this.wildHandler.resolveExpandingWilds(this.grid);

    // ── Cascade loop ─────────────────────────────────────────
    while (true) {
      const clusters = detectClusters(this.grid);

      if (clusters.length === 0) break;

      // Payout for this cascade step
      const { totalWin: stepWin, breakdown } =
        calculatePayout(clusters, this.grid, bet, this.isBonus ? this.chainMult : 1);

      totalWin += stepWin;

      // Check if clusters touch grid edges → expand
      const edgeTouching = checkEdgeTouching(clusters, this.grid);
      const rowExpansions = [];
      if (edgeTouching.above) {
        const exp = this.grid.expandRow('above');
        if (exp) rowExpansions.push(exp);
      }
      if (edgeTouching.below) {
        const exp = this.grid.expandRow('below');
        if (exp) rowExpansions.push(exp);
      }

      // Get winning cell positions
      const winCells = getWinningCells(clusters);

      // Remove winning cells (sticky wilds stay)
      const removed = this.grid.removeCells(winCells);

      // Lock sticky wilds that survived
      this.wildHandler.lockStickyWilds(this.grid);

      // Apply gravity
      const moves = this.grid.applyGravity();

      // Fill empty cells
      const spawned = this.grid.fillEmpty();

      // Bonus: increment chain multiplier
      if (this.isBonus) this.chainMult++;

      // Record step
      steps.push({
        clusters,
        breakdown,
        stepWin,
        winCells,
        removed,
        rowExpansions,
        moves,
        spawned,
        expansions: steps.length === 0 ? expansions : [],
        chainMult: this.chainMult,
        gridRows: this.grid.rows,
        gridCols: this.grid.cols,
      });
    }

    // Count scatters on final grid state
    scatters = countScatters(this.grid);

    return {
      steps,
      totalWin,
      scatters,
      finalGridSnapshot: this._snapshotGrid(),
      triggeredBonus: scatters >= 3 && !this.isBonus,
    };
  }

  // ── Snapshot the current grid for the renderer ────────────
  _snapshotGrid() {
    const snap = [];
    for (let r = 0; r < this.grid.rows; r++) {
      const row = [];
      for (let c = 0; c < this.grid.cols; c++) {
        const cell = this.grid.getCell(r, c);
        row.push(cell ? { ...cell } : null);
      }
      snap.push(row);
    }
    return snap;
  }

  // ── Enter bonus mode ──────────────────────────────────────
  enterBonus() {
    this.isBonus   = true;
    this.chainMult = 1;
  }

  // ── Exit bonus mode ───────────────────────────────────────
  exitBonus() {
    this.isBonus   = false;
    this.chainMult = 1;
    this.wildHandler.unlockStickyWilds(this.grid);
  }
}
