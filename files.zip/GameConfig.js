// ============================================================
//  GameConfig.js
//  Central tuning knobs — change these to affect feel & RTP
// ============================================================

export const GRID = {
  COLS: 5,
  ROWS_BASE: 3,       // starting visible rows
  ROWS_MAX: 5,        // max after expansion (2 above + 2 below)
  CELL_SIZE: 96,      // px — symbol tile size
  PADDING: 8,         // px — gap between tiles
};

export const CLUSTER = {
  MIN_SIZE: 3,        // minimum symbols to count as a win
  DIAGONALS: true,    // 8-directional cluster detection
};

// ── Volatility presets ──────────────────────────────────────
// Each preset tweaks symbol weights + wild/scatter frequency.
// LOW  = frequent small wins  (higher base hit rate, ~96% RTP feel)
// MED  = balanced             (~94% RTP feel)
// HIGH = rare but big wins    (~92% RTP feel)

export const VOLATILITY = {
  LOW:  'low',
  MED:  'med',
  HIGH: 'high',
};

export const VOLATILITY_PRESETS = {
  low: {
    symbolCountInPool: 6,       // fewer distinct symbols → more clusters
    wildFrequency:     0.06,    // chance any given cell spawns a wild
    scatterFrequency:  0.025,
    multiplierWildFrequency: 0.02,
    expandingWildFrequency:  0.01,
    stickyWildFrequency:     0.015,
    stickyMultiplierFrequency: 0.005,
  },
  med: {
    symbolCountInPool: 7,
    wildFrequency:     0.045,
    scatterFrequency:  0.018,
    multiplierWildFrequency: 0.015,
    expandingWildFrequency:  0.008,
    stickyWildFrequency:     0.010,
    stickyMultiplierFrequency: 0.003,
  },
  high: {
    symbolCountInPool: 8,
    wildFrequency:     0.03,
    scatterFrequency:  0.012,
    multiplierWildFrequency: 0.010,
    expandingWildFrequency:  0.005,
    stickyWildFrequency:     0.007,
    stickyMultiplierFrequency: 0.002,
  },
};

// Active volatility — change this to switch modes
export let activeVolatility = VOLATILITY.MED;
export function setVolatility(v) { activeVolatility = v; }
export function getPreset() { return VOLATILITY_PRESETS[activeVolatility]; }

// ── Multiplier Wild values & their relative weights ─────────
export const MULTIPLIER_WILD_VALUES = [
  { value: 2,  weight: 50 },
  { value: 3,  weight: 30 },
  { value: 5,  weight: 15 },
  { value: 10, weight: 5  },   // rare x10
];

// ── Free spin wheel outcomes per scatter count ───────────────
export const FREE_SPIN_OUTCOMES = {
  3: [5, 6, 7, 8, 9, 10],
  4: [8, 9, 10, 12, 14, 16],
  5: [10, 12, 15, 18, 20, 25, 30],
};

// ── Betting ──────────────────────────────────────────────────
export const BET = {
  MIN:     1,
  MAX:     500,
  DEFAULT: 10,
  STEPS:   [1, 2, 5, 10, 20, 50, 100, 200, 500],
};

// ── Animation timings (ms) ───────────────────────────────────
export const ANIM = {
  SYMBOL_DROP_DURATION:   400,   // how long a symbol takes to fall into place
  SYMBOL_DROP_STAGGER:    40,    // delay between each column starting to drop
  CLUSTER_FLASH_DURATION: 600,   // how long winning cluster flashes before destroy
  DESTROY_DURATION:       250,   // symbol pop-out animation
  CASCADE_PAUSE:          200,   // brief pause between cascade steps
  EXPAND_DURATION:        300,   // grid row expansion animation
};
