// ============================================================
//  main.js
//  Phaser game bootstrap.
// ============================================================

import { BootScene } from './scenes/BootScene.js';
import { GameScene } from './scenes/GameScene.js';
import { UIScene }   from './scenes/UIScene.js';

const config = {
  type:            Phaser.AUTO,
  width:           900,
  height:          700,
  backgroundColor: '#081f16',
  parent:          'game-container',
  scene:           [BootScene, GameScene, UIScene],
  scale: {
    mode:       Phaser.Scale.FIT,
    autoCenter: Phaser.Scale.CENTER_BOTH,
  },
};

const game = new window.Phaser.Game(config);
