// ============================================================
//  UIScene.js
//  Runs in parallel with GameScene.
//  Handles: balance, bet controls, spin button, win display.
// ============================================================

import { BET } from '../config/GameConfig.js';

export class UIScene extends Phaser.Scene {
  constructor() {
    super({ key: 'UIScene' });
  }

  create() {
    this.balance    = 1000;
    this.bet        = BET.DEFAULT;
    this.betStepIdx = BET.STEPS.indexOf(BET.DEFAULT);
    this.totalWin   = 0;
    this.spinning   = false;

    this._buildHUD();

    // Listen for game events
    this.game.events.on('spinStart', () => {
      this.spinning = true;
      this.balance -= this.bet;
      this._updateLabels();
      this.spinBtn.setAlpha(0.5).disableInteractive();
    });

    this.game.events.on('stepWin', ({ win, total }) => {
      this.totalWin = total;
      this._updateWinLabel(total);
    });

    this.game.events.on('spinEnd', ({ totalWin }) => {
      this.spinning = false;
      this.balance += totalWin;
      this._updateLabels();
      this.spinBtn.setAlpha(1).setInteractive();
    });

    this.game.events.on('bonusTriggered', ({ freeSpins, scatterCount }) => {
      this._showBonusAnnounce(freeSpins, scatterCount);
    });
  }

  _buildHUD() {
    const { width, height } = this.scale;
    const hudY = height - 70;

    // HUD background bar
    this.add.rectangle(width / 2, hudY, width, 100, 0x080808, 0.92);
    this.add.rectangle(width / 2, hudY - 48, width, 2, 0x2a2a2a);

    // ── Balance ──────────────────────────────────────────────
    this._hudLabel(60, hudY - 18, 'BALANCE');
    this.balanceText = this._hudValue(60, hudY + 8, `$${this.balance.toLocaleString()}`);

    // ── Total win ────────────────────────────────────────────
    this._hudLabel(width / 2, hudY - 18, 'WIN');
    this.winText = this._hudValue(width / 2, hudY + 8, '$0');

    // ── Bet controls ─────────────────────────────────────────
    this._hudLabel(width - 180, hudY - 18, 'BET');
    this.betText = this._hudValue(width - 180, hudY + 8, `$${this.bet}`);

    // Bet –
    const btnMinus = this.add.text(width - 240, hudY + 8, '◄', {
      fontFamily: 'sans-serif', fontSize: '20px', color: '#c9a84c',
    }).setOrigin(0.5).setInteractive({ useHandCursor: true });
    btnMinus.on('pointerdown', () => this._changeBet(-1));

    // Bet +
    const btnPlus = this.add.text(width - 120, hudY + 8, '►', {
      fontFamily: 'sans-serif', fontSize: '20px', color: '#c9a84c',
    }).setOrigin(0.5).setInteractive({ useHandCursor: true });
    btnPlus.on('pointerdown', () => this._changeBet(1));

    // ── Spin button ──────────────────────────────────────────
    const spinBg = this.add.rectangle(width / 2, hudY + 8, 160, 44, 0xc0392b, 1)
      .setStrokeStyle(1, 0xff6b6b)
      .setInteractive({ useHandCursor: true });

    const spinLabel = this.add.text(width / 2, hudY + 8, 'SPIN', {
      fontFamily: 'Georgia, serif',
      fontSize:   '22px',
      fontStyle:  'bold',
      color:      '#f5edd8',
      letterSpacing: 6,
    }).setOrigin(0.5);

    spinBg.on('pointerdown', () => {
      if (!this.spinning && this.balance >= this.bet) {
        this.totalWin = 0;
        this._updateWinLabel(0);
        this.game.events.emit('spin');
      }
    });
    spinBg.on('pointerover',  () => spinBg.setFillStyle(0xe74c3c));
    spinBg.on('pointerout',   () => spinBg.setFillStyle(0xc0392b));

    this.spinBtn = spinBg;
  }

  _hudLabel(x, y, text) {
    return this.add.text(x, y, text, {
      fontFamily: 'sans-serif',
      fontSize:   '11px',
      color:      '#7a6030',
      letterSpacing: 3,
    }).setOrigin(0.5);
  }

  _hudValue(x, y, text) {
    return this.add.text(x, y, text, {
      fontFamily: 'Georgia, serif',
      fontSize:   '22px',
      color:      '#f0d080',
      fontStyle:  'bold',
    }).setOrigin(0.5);
  }

  _changeBet(dir) {
    this.betStepIdx = Phaser.Math.Clamp(
      this.betStepIdx + dir, 0, BET.STEPS.length - 1
    );
    this.bet = BET.STEPS[this.betStepIdx];
    this.betText.setText(`$${this.bet}`);
    this.game.events.emit('betChanged', this.bet);
  }

  _updateLabels() {
    this.balanceText.setText(`$${this.balance.toLocaleString()}`);
  }

  _updateWinLabel(amount) {
    this.winText.setText(amount > 0 ? `$${amount.toFixed(2)}` : '$0');
  }

  _showBonusAnnounce(freeSpins, scatterCount) {
    const { width, height } = this.scale;
    const panel = this.add.rectangle(width / 2, height / 2, 420, 180, 0x0a0505, 0.95)
      .setStrokeStyle(2, 0xc9a84c);

    const title = this.add.text(width / 2, height / 2 - 40, 'FREE SPINS!', {
      fontFamily: 'Georgia, serif',
      fontSize:   '36px',
      fontStyle:  'bold',
      color:      '#f0d080',
      letterSpacing: 8,
    }).setOrigin(0.5);

    const sub = this.add.text(width / 2, height / 2 + 10,
      `${scatterCount} SCATTERS → ${freeSpins} FREE SPINS`, {
      fontFamily: 'sans-serif',
      fontSize:   '16px',
      color:      '#c9a84c',
      letterSpacing: 4,
    }).setOrigin(0.5);

    // Auto-dismiss after 2.5s
    this.time.delayedCall(2500, () => {
      [panel, title, sub].forEach(o => o.destroy());
    });
  }
}
