// ============================================================
//  Cluster.js
//  Pure logic — finds all winning clusters on the grid.
//  Uses 8-directional flood fill. Wilds join any cluster.
// ============================================================

import { CLUSTER } from '../config/GameConfig.js';
import { isWild, isScatter } from '../config/SymbolConfig.js';

// ── Main export ───────────────────────────────────────────────
// Returns array of clusters, each cluster is:
// {
//   symbolId: string,         — the pay symbol this cluster is made of
//   cells: [{row, col}, ...], — all cells in the cluster
//   size: number,
//   wilds: [{row, col}, ...], — wild cells that joined this cluster
// }
export function detectClusters(grid) {
  const visited = Array.from({ length: grid.rows }, () =>
    new Array(grid.cols).fill(false)
  );
  const clusters = [];

  for (let r = 0; r < grid.rows; r++) {
    for (let c = 0; c < grid.cols; c++) {
      if (visited[r][c]) continue;

      const cell = grid.getCell(r, c);
      if (!cell) continue;
      if (isWild(cell.id) || isScatter(cell.id)) continue; // wilds attach, not seed

      // Flood fill from this cell
      const cluster = floodFill(grid, r, c, cell.id, visited);

      if (cluster.size >= CLUSTER.MIN_SIZE) {
        clusters.push(cluster);
      }
    }
  }

  return clusters;
}

// ── Flood fill ────────────────────────────────────────────────
function floodFill(grid, startRow, startCol, targetId, visited) {
  const cells  = [];
  const wilds  = [];
  const queue  = [{ r: startRow, c: startCol }];
  const inQueue = new Set();
  inQueue.add(`${startRow},${startCol}`);

  const dirs = CLUSTER.DIAGONALS
    ? [[-1,-1],[-1,0],[-1,1],[0,-1],[0,1],[1,-1],[1,0],[1,1]]
    : [[-1,0],[0,-1],[0,1],[1,0]];

  while (queue.length > 0) {
    const { r, c } = queue.shift();
    if (visited[r][c]) continue;

    const cell = grid.getCell(r, c);
    if (!cell) continue;

    const cellIsWild    = isWild(cell.id);
    const cellIsTarget  = cell.id === targetId;

    if (!cellIsWild && !cellIsTarget) continue;

    visited[r][c] = true;

    if (cellIsWild) {
      wilds.push({ row: r, col: c });
    } else {
      cells.push({ row: r, col: c });
    }

    // Spread to neighbours
    for (const [dr, dc] of dirs) {
      const nr = r + dr;
      const nc = c + dc;
      const key = `${nr},${nc}`;
      if (inQueue.has(key)) continue;
      if (nr < 0 || nr >= grid.rows || nc < 0 || nc >= grid.cols) continue;

      const neighbour = grid.getCell(nr, nc);
      if (!neighbour) continue;
      if (isScatter(neighbour.id)) continue;

      const nIsWild   = isWild(neighbour.id);
      const nIsTarget = neighbour.id === targetId;

      if (nIsWild || nIsTarget) {
        inQueue.add(key);
        queue.push({ r: nr, c: nc });
      }
    }
  }

  return {
    symbolId: targetId,
    cells,
    wilds,
    size: cells.length + wilds.length,
  };
}

// ── Count scatters on the grid ────────────────────────────────
export function countScatters(grid) {
  let count = 0;
  for (let r = 0; r < grid.rows; r++) {
    for (let c = 0; c < grid.cols; c++) {
      const cell = grid.getCell(r, c);
      if (cell && isScatter(cell.id)) count++;
    }
  }
  return count;
}

// ── Get all cells belonging to winning clusters (flat list) ──
export function getWinningCells(clusters) {
  const all = new Set();
  for (const cluster of clusters) {
    for (const { row, col } of cluster.cells)  all.add(`${row},${col}`);
    for (const { row, col } of cluster.wilds)  all.add(`${row},${col}`);
  }
  return [...all].map(key => {
    const [row, col] = key.split(',').map(Number);
    return { row, col };
  });
}

// ── Check if any winning cluster touches the grid edge ────────
// Returns { above: bool, below: bool }
export function checkEdgeTouching(clusters, grid) {
  let above = false;
  let below = false;
  const topRow    = 0;
  const bottomRow = grid.rows - 1;

  for (const cluster of clusters) {
    const allCells = [...cluster.cells, ...cluster.wilds];
    for (const { row } of allCells) {
      if (row === topRow)    above = true;
      if (row === bottomRow) below = true;
    }
  }
  return { above, below };
}
