// ============================================================
//  Grid.js
//  Pure game logic — no Phaser dependency.
//  Manages the 2D grid state, symbol spawning, and expansion.
// ============================================================

import { GRID } from '../config/GameConfig.js';
import { SYM, PAY_SYMBOLS, isWild, isSticky, isExpandingWild, isScatter }
  from '../config/SymbolConfig.js';
import { getPreset, MULTIPLIER_WILD_VALUES } from '../config/GameConfig.js';

// ── Cell object shape ────────────────────────────────────────
// {
//   id:          string   — symbol type (SYM.*)
//   row:         number   — current row index (0 = top)
//   col:         number   — column index
//   multiplier:  number|null — only on multiplier wilds
//   sticky:      boolean  — stays on cascade/bonus
//   locked:      boolean  — currently locked (sticky wild in place)
// }

export class Grid {
  constructor() {
    this.cols      = GRID.COLS;
    this.rowsBase  = GRID.ROWS_BASE;
    this.rowsMax   = GRID.ROWS_MAX;

    // Expansion state: how many rows have expanded above/below base
    this.expandedAbove = 0;
    this.expandedBelow = 0;

    // The live grid: cells[row][col] — row 0 is topmost visible row
    this.cells = [];

    this.init();
  }

  // ── Total currently visible rows ──────────────────────────
  get rows() {
    return this.rowsBase + this.expandedAbove + this.expandedBelow;
  }

  // ── Maximum rows we can still add above / below ───────────
  get canExpandAbove() { return this.expandedAbove < 2; }
  get canExpandBelow() { return this.expandedBelow < 2; }

  // ── Build a fresh grid ────────────────────────────────────
  init() {
    this.expandedAbove = 0;
    this.expandedBelow = 0;
    this.cells = [];
    for (let r = 0; r < this.rowsBase; r++) {
      this.cells.push(this._makeRow(r));
    }
  }

  // ── Reset grid (new base spin, clear non-sticky) ──────────
  reset(keepSticky = false) {
    const stickySnapshot = keepSticky ? this._extractSticky() : {};

    this.expandedAbove = 0;
    this.expandedBelow = 0;
    this.cells = [];

    for (let r = 0; r < this.rowsBase; r++) {
      this.cells.push(this._makeRow(r));
    }

    // Re-place sticky wilds at their original positions
    if (keepSticky) {
      for (const [key, cell] of Object.entries(stickySnapshot)) {
        const [r, c] = key.split(',').map(Number);
        if (r < this.rows && c < this.cols) {
          this.cells[r][c] = { ...cell, row: r, col: c };
        }
      }
    }
  }

  // ── Extract all sticky wild positions ────────────────────
  _extractSticky() {
    const out = {};
    for (let r = 0; r < this.rows; r++) {
      for (let c = 0; c < this.cols; c++) {
        const cell = this.cells[r][c];
        if (cell && isSticky(cell.id)) {
          out[`${r},${c}`] = { ...cell };
        }
      }
    }
    return out;
  }

  // ── Generate a single row of random cells ─────────────────
  _makeRow(rowIndex) {
    const row = [];
    for (let c = 0; c < this.cols; c++) {
      row.push(this._randomCell(rowIndex, c));
    }
    return row;
  }

  // ── Spawn a random cell ───────────────────────────────────
  _randomCell(row, col) {
    const preset = getPreset();
    const rand = Math.random();

    // Special symbol spawn order (checked sequentially, rarest first)
    if (rand < preset.stickyMultiplierFrequency) {
      return this._makeSpecialCell(row, col, SYM.WILD_STICKY_MULT, true, true);
    }
    const r2 = rand - preset.stickyMultiplierFrequency;

    if (r2 < preset.expandingWildFrequency) {
      return this._makeSpecialCell(row, col, SYM.WILD_EXPANDING);
    }
    const r3 = r2 - preset.expandingWildFrequency;

    if (r3 < preset.stickyWildFrequency) {
      return this._makeSpecialCell(row, col, SYM.WILD_STICKY, true);
    }
    const r4 = r3 - preset.stickyWildFrequency;

    if (r4 < preset.multiplierWildFrequency) {
      return this._makeSpecialCell(row, col, SYM.WILD_MULTIPLIER, false, true);
    }
    const r5 = r4 - preset.multiplierWildFrequency;

    if (r5 < preset.wildFrequency) {
      return this._makeSpecialCell(row, col, SYM.WILD);
    }
    const r6 = r5 - preset.wildFrequency;

    if (r6 < preset.scatterFrequency) {
      return { id: SYM.SCATTER, row, col, multiplier: null, sticky: false, locked: false };
    }

    // Regular pay symbol
    return { id: this._randomPaySymbol(), row, col, multiplier: null, sticky: false, locked: false };
  }

  _makeSpecialCell(row, col, id, sticky = false, hasMultiplier = false) {
    let multiplier = null;
    if (hasMultiplier) {
      multiplier = this._rollMultiplierValue();
    }
    return { id, row, col, multiplier, sticky, locked: sticky };
  }

  _rollMultiplierValue() {
    const pool = MULTIPLIER_WILD_VALUES;
    const total = pool.reduce((s, e) => s + e.weight, 0);
    let r = Math.random() * total;
    for (const entry of pool) {
      r -= entry.weight;
      if (r <= 0) return entry.value;
    }
    return pool[0].value;
  }

  _randomPaySymbol() {
    const preset = getPreset();
    const available = PAY_SYMBOLS.slice(0, preset.symbolCountInPool);
    const total = available.reduce((s, sym) => s + sym.weight, 0);
    let r = Math.random() * total;
    for (const sym of available) {
      r -= sym.weight;
      if (r <= 0) return sym.id;
    }
    return available[0].id;
  }

  // ── Get cell (safe — returns null if out of bounds) ───────
  getCell(row, col) {
    if (row < 0 || row >= this.rows || col < 0 || col >= this.cols) return null;
    return this.cells[row]?.[col] ?? null;
  }

  // ── Remove specific cells (by winning cluster) ────────────
  // Returns list of {row, col} cells that were actually removed
  removeCells(positions) {
    const removed = [];
    for (const { row, col } of positions) {
      const cell = this.getCell(row, col);
      if (!cell || cell.locked) continue;   // sticky wilds stay
      this.cells[row][col] = null;
      removed.push({ row, col });
    }
    return removed;
  }

  // ── Apply gravity: drop symbols down to fill gaps ─────────
  // Returns array of move descriptors: { id, from: {r,c}, to: {r,c} }
  applyGravity() {
    const moves = [];
    for (let c = 0; c < this.cols; c++) {
      // Collect non-null cells from bottom to top
      const stack = [];
      for (let r = this.rows - 1; r >= 0; r--) {
        if (this.cells[r][c] !== null) stack.push(this.cells[r][c]);
      }
      // Place them back from bottom up
      for (let r = this.rows - 1; r >= 0; r--) {
        const cell = stack.shift() ?? null;
        if (cell && cell.row !== r) {
          moves.push({ id: cell.id, from: { r: cell.row, c }, to: { r, c } });
        }
        if (cell) cell.row = r;
        this.cells[r][c] = cell;
      }
    }
    return moves;
  }

  // ── Fill all null cells with new spawns ───────────────────
  // Returns array of new cell descriptors for animation
  fillEmpty() {
    const spawned = [];
    for (let r = 0; r < this.rows; r++) {
      for (let c = 0; c < this.cols; c++) {
        if (this.cells[r][c] === null) {
          const cell = this._randomCell(r, c);
          this.cells[r][c] = cell;
          spawned.push({ ...cell });
        }
      }
    }
    return spawned;
  }

  // ── Expanding wild: fill entire column ────────────────────
  // Called by WildHandler before cluster detection
  expandColumn(col) {
    const expanded = [];
    for (let r = 0; r < this.rows; r++) {
      const existing = this.cells[r][col];
      if (!existing || existing.id !== SYM.WILD_EXPANDING) {
        this.cells[r][col] = {
          id: SYM.WILD_EXPANDING,
          row: r, col,
          multiplier: null, sticky: false, locked: false,
          _fromExpansion: true,
        };
        expanded.push({ row: r, col });
      }
    }
    return expanded;
  }

  // ── Grid row expansion ────────────────────────────────────
  // Adds one row above or below. Returns the new row's cells.
  expandRow(direction = 'above') {
    if (direction === 'above' && this.canExpandAbove) {
      const newRow = this._makeRow(0);
      this.cells.unshift(newRow);
      // Re-index all rows
      this._reindexRows();
      this.expandedAbove++;
      return { direction: 'above', cells: newRow };
    }
    if (direction === 'below' && this.canExpandBelow) {
      const newRow = this._makeRow(this.rows);
      this.cells.push(newRow);
      this._reindexRows();
      this.expandedBelow++;
      return { direction: 'below', cells: newRow };
    }
    return null;
  }

  _reindexRows() {
    for (let r = 0; r < this.cells.length; r++) {
      for (let c = 0; c < this.cols; c++) {
        if (this.cells[r][c]) this.cells[r][c].row = r;
      }
    }
  }

  // ── Snapshot grid for debugging ───────────────────────────
  debug() {
    console.table(
      this.cells.map(row => row.map(c => c ? c.id.slice(0,6) : '·'))
    );
  }
}
