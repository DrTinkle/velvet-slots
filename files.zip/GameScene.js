// ============================================================
//  GameScene.js
//  Main game scene — renders the grid, animates cascades.
//  Talks to pure-logic layer (CascadeManager) for all math.
// ============================================================

import { CascadeManager }  from '../game/CascadeManager.js';
import { ScatterHandler }  from '../game/ScatterHandler.js';
import { GRID, ANIM }      from '../config/GameConfig.js';
import { SYM, isMultiplierWild, isSticky, isExpandingWild }
  from '../config/SymbolConfig.js';

const CELL  = GRID.CELL_SIZE;
const PAD   = GRID.PADDING;
const STEP  = CELL + PAD;

export class GameScene extends Phaser.Scene {
  constructor() {
    super({ key: 'GameScene' });
  }

  // ────────────────────────────────────────────────────────
  create() {
    this.cascade  = new CascadeManager();
    this.scatter  = new ScatterHandler();
    this.spinning = false;
    this.bet      = 10;

    // Symbol sprite containers keyed by "row,col"
    this.symbolSprites = {};

    // Grid visual offset (centered on screen)
    this._calcGridOffset();

    // Background
    this._buildBackground();

    // Draw initial grid
    this._drawFullGrid();

    // Listen for spin event from UIScene
    this.game.events.on('spin', this._onSpin, this);
    this.game.events.on('betChanged', (val) => { this.bet = val; }, this);
  }

  // ────────────────────────────────────────────────────────
  _calcGridOffset() {
    const { width, height } = this.scale;
    const gridW = this.cascade.grid.cols * STEP - PAD;
    const gridH = GRID.ROWS_MAX * STEP - PAD;   // use max height for centering
    this.originX = (width  - gridW) / 2;
    this.originY = (height - gridH) / 2 + 20;
  }

  _buildBackground() {
    const { width, height } = this.scale;
    // Deep felt background
    this.add.rectangle(width / 2, height / 2, width, height, 0x081f16);

    // Grid backdrop panel
    const gridW = GRID.COLS  * STEP - PAD + 24;
    const gridH = GRID.ROWS_MAX * STEP - PAD + 24;
    this.add.rectangle(
      this.originX + (GRID.COLS * STEP - PAD) / 2,
      this.originY + (GRID.ROWS_MAX * STEP - PAD) / 2,
      gridW, gridH, 0x0a0a0a, 0.7
    ).setStrokeStyle(1, 0x2a2a2a);
  }

  // ── Draw the full grid from scratch ─────────────────────
  _drawFullGrid() {
    // Clear existing sprites
    Object.values(this.symbolSprites).forEach(s => s.destroy());
    this.symbolSprites = {};

    const grid = this.cascade.grid;

    // Calculate row offset due to expansion
    const rowOffset = (GRID.ROWS_MAX - grid.rows) / 2;

    for (let r = 0; r < grid.rows; r++) {
      for (let c = 0; c < grid.cols; c++) {
        const cell = grid.getCell(r, c);
        if (cell) this._createSymbolSprite(cell, r + rowOffset, c);
      }
    }
  }

  // ── Create a symbol sprite at visual position ───────────
  _createSymbolSprite(cell, visualRow, col) {
    const x = this.originX + col * STEP + CELL / 2;
    const y = this.originY + visualRow * STEP + CELL / 2;

    const sprite = this.add.image(x, y, cell.id).setDisplaySize(CELL - 4, CELL - 4);

    // Multiplier badge
    if (cell.multiplier) {
      const badge = this.add.text(x + 24, y + 24, `×${cell.multiplier}`, {
        fontFamily: 'sans-serif',
        fontSize:   '13px',
        fontStyle:  'bold',
        color:      '#ffffff',
        backgroundColor: '#e65c00',
        padding:    { x: 4, y: 2 },
      }).setOrigin(0.5).setDepth(10);
      sprite._badge = badge;
    }

    // Sticky indicator ring
    if (isSticky(cell.id)) {
      const ring = this.add.circle(x, y, CELL / 2 - 2, 0x69f0ae, 0)
        .setStrokeStyle(3, 0x69f0ae, 0.7);
      sprite._ring = ring;
    }

    this.symbolSprites[`${cell.row},${cell.col}`] = sprite;
    return sprite;
  }

  // ── Handle spin event ────────────────────────────────────
  async _onSpin() {
    if (this.spinning) return;
    this.spinning = true;
    this.game.events.emit('spinStart');

    const result = this.cascade.startSpin(this.bet, this.cascade.isBonus);

    if (result.steps.length === 0) {
      // No wins — just redraw
      this._drawFullGrid();
      this._checkBonusTrigger(result);
      this.spinning = false;
      this.game.events.emit('spinEnd', { totalWin: 0, scatters: result.scatters });
      return;
    }

    // Animate each cascade step
    let totalWin = 0;
    for (const step of result.steps) {
      await this._animateCascadeStep(step);
      totalWin += step.stepWin;
      this.game.events.emit('stepWin', { win: step.stepWin, total: totalWin });
    }

    this._checkBonusTrigger(result);
    this.spinning = false;
    this.game.events.emit('spinEnd', { totalWin, scatters: result.scatters });
  }

  // ── Animate one cascade step ─────────────────────────────
  async _animateCascadeStep(step) {

    // 1. Expanding wilds (first step only)
    if (step.expansions && step.expansions.length > 0) {
      await this._animateExpandingWilds(step.expansions);
    }

    // 2. Flash winning clusters
    await this._flashWinningCells(step.winCells);

    // 3. Row expansion animation
    if (step.rowExpansions.length > 0) {
      await this._animateRowExpansion(step.rowExpansions, step.gridRows);
    }

    // 4. Destroy winning cells
    await this._destroyWinningCells(step.removed);

    // 5. Drop existing symbols
    await this._animateDrops(step.moves, step.gridRows);

    // 6. Spawn new symbols from top
    await this._animateSpawns(step.spawned, step.gridRows);

    // Pause between cascades
    await this._wait(ANIM.CASCADE_PAUSE);
  }

  // ── Flash winning cells ──────────────────────────────────
  _flashWinningCells(winCells) {
    return new Promise(resolve => {
      for (const { row, col } of winCells) {
        const sprite = this._getSprite(row, col);
        if (!sprite) continue;
        this.tweens.add({
          targets:  sprite,
          alpha:    { from: 1, to: 0.3 },
          yoyo:     true,
          repeat:   3,
          duration: ANIM.CLUSTER_FLASH_DURATION / 8,
          ease:     'Sine.easeInOut',
        });
      }
      this.time.delayedCall(ANIM.CLUSTER_FLASH_DURATION, resolve);
    });
  }

  // ── Destroy winning cells ────────────────────────────────
  _destroyWinningCells(removed) {
    return new Promise(resolve => {
      let count = removed.length;
      if (count === 0) { resolve(); return; }

      for (const { row, col } of removed) {
        const sprite = this._getSprite(row, col);
        if (!sprite) { count--; if (count === 0) resolve(); continue; }

        this.tweens.add({
          targets:  sprite,
          scaleX:   0, scaleY: 0,
          alpha:    0,
          duration: ANIM.DESTROY_DURATION,
          ease:     'Back.easeIn',
          onComplete: () => {
            sprite._badge?.destroy();
            sprite._ring?.destroy();
            sprite.destroy();
            delete this.symbolSprites[`${row},${col}`];
            count--;
            if (count === 0) resolve();
          },
        });
      }
    });
  }

  // ── Animate symbols dropping into new positions ──────────
  _animateDrops(moves, gridRows) {
    return new Promise(resolve => {
      if (moves.length === 0) { resolve(); return; }
      let count = moves.length;

      const rowOffset = (GRID.ROWS_MAX - gridRows) / 2;

      for (const move of moves) {
        const sprite = this._getSprite(move.from.r, move.from.c);
        if (!sprite) { count--; if (count === 0) resolve(); continue; }

        const targetY = this.originY + (move.to.r + rowOffset) * STEP + CELL / 2;

        // Re-key in symbolSprites
        delete this.symbolSprites[`${move.from.r},${move.from.c}`];
        this.symbolSprites[`${move.to.r},${move.to.c}`] = sprite;

        this.tweens.add({
          targets:  sprite,
          y:        targetY,
          duration: ANIM.SYMBOL_DROP_DURATION,
          ease:     'Bounce.easeOut',
          delay:    move.from.c * ANIM.SYMBOL_DROP_STAGGER,
          onComplete: () => {
            sprite._badge?.setY(targetY + 24);
            sprite._ring?.setY(targetY);
            count--;
            if (count === 0) resolve();
          },
        });
      }
    });
  }

  // ── Animate new symbols spawning from above ──────────────
  _animateSpawns(spawned, gridRows) {
    return new Promise(resolve => {
      if (spawned.length === 0) { resolve(); return; }
      let count = spawned.length;

      const rowOffset = (GRID.ROWS_MAX - gridRows) / 2;

      for (const cell of spawned) {
        const x = this.originX + cell.col * STEP + CELL / 2;
        const y = this.originY + (cell.row + rowOffset) * STEP + CELL / 2;
        const startY = this.originY - CELL * 2;

        const sprite = this.add.image(x, startY, cell.id)
          .setDisplaySize(CELL - 4, CELL - 4)
          .setAlpha(0);

        this.symbolSprites[`${cell.row},${cell.col}`] = sprite;

        this.tweens.add({
          targets:  sprite,
          y,
          alpha:    1,
          duration: ANIM.SYMBOL_DROP_DURATION,
          ease:     'Bounce.easeOut',
          delay:    cell.col * ANIM.SYMBOL_DROP_STAGGER,
          onComplete: () => {
            count--;
            if (count === 0) resolve();
          },
        });
      }
    });
  }

  // ── Expanding wild column fill animation ─────────────────
  _animateExpandingWilds(expansions) {
    return new Promise(resolve => {
      let count = expansions.length;
      for (const { col, expandedCells } of expansions) {
        for (const { row, col: c } of expandedCells) {
          const x = this.originX + c * STEP + CELL / 2;
          const y = this.originY + row * STEP + CELL / 2;
          const sprite = this.add.image(x, y, SYM.WILD_EXPANDING)
            .setDisplaySize(CELL - 4, CELL - 4)
            .setAlpha(0)
            .setScale(0.5);
          this.symbolSprites[`${row},${c}`] = sprite;
          this.tweens.add({
            targets: sprite,
            alpha: 1, scaleX: 1, scaleY: 1,
            duration: ANIM.EXPAND_DURATION,
            ease: 'Back.easeOut',
          });
        }
        this.time.delayedCall(ANIM.EXPAND_DURATION, () => {
          count--;
          if (count === 0) resolve();
        });
      }
      if (expansions.length === 0) resolve();
    });
  }

  // ── Row expansion animation ──────────────────────────────
  _animateRowExpansion(rowExpansions, gridRows) {
    return new Promise(resolve => {
      // Simply re-draw the full grid repositioned
      // A more sophisticated version could slide existing rows
      this._drawFullGrid();
      this.time.delayedCall(ANIM.EXPAND_DURATION, resolve);
    });
  }

  // ── Check for bonus trigger ──────────────────────────────
  _checkBonusTrigger(result) {
    if (result.triggeredBonus) {
      const { freeSpins, scatterCount } =
        this.scatter.rollFreeSpins(result.scatters);
      this.game.events.emit('bonusTriggered', { freeSpins, scatterCount });
    }
  }

  // ── Utility ──────────────────────────────────────────────
  _getSprite(row, col) {
    return this.symbolSprites[`${row},${col}`] ?? null;
  }

  _wait(ms) {
    return new Promise(resolve => this.time.delayedCall(ms, resolve));
  }
}
